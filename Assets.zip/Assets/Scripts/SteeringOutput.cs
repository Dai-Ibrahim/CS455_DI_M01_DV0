﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SteeringOutput : MonoBehaviour
{
    public Vector3 velocity;
	public float rotation;
	
}
