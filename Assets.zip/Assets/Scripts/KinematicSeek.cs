﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KinematicSeek : MonoBehaviour
{
    public float maxSpeed = 5f;
	public Transform enemy;
	public Transform target;

	public class SteeringOutput 
	{
		public Vector3 velocity;
		public float rotation;

	}

    void Update()
    {
     SteeringOutput dingus = getSteering();
	 enemy.transform.position += dingus.velocity*Time.deltaTime;	 	
    }
	
	SteeringOutput getSteering()
	{
		SteeringOutput result = new SteeringOutput();
		result.velocity = target.position - enemy.position;
		result.velocity.Normalize();
		result.velocity *= maxSpeed;
		
		float angleDeg = newOrientation(enemy.transform.eulerAngles.y, result.velocity);
		angleDeg *= Mathf.Rad2Deg;
		enemy.transform.eulerAngles = new Vector3 (0,angleDeg,0);
		result.rotation = 0;
		return result;
	}

	float newOrientation(float current , Vector3 velocity)
	{
		
		if (velocity.magnitude > 0)
			{
				return Mathf.Atan2(velocity.x, velocity.z); // result is in radians
			}
			else
			{
				return current;
			}
	}

}

